# Sport Racing 3D

A browser-playable 3D highway racing prototype built with Three.js. Designed for GitHub Pages and mobile touch controls.

## Run
Enable GitHub Pages using **GitHub Actions** and deploy from `.github/workflows/pages.yml`. Open the Pages URL on a phone. Internet is required to load Three.js from jsDelivr.

## Controls
- Touch: left/right, GO, BRAKE, NITRO
- Keyboard: arrow keys or WASD; Space for nitro

## Notes
This is a playable prototype, not a finished commercial game. It uses fictional car designs and does not include licensed real-world vehicle brands. Progress is saved in the browser on the current device. A native Android APK/AAB and Google Play release require a separate Android packaging, testing, signing, privacy-policy and Play Console process.

## Progression update
- Stages unlock sequentially, up to the final Stage 1,000,000.
- Completing a stage automatically saves progress in browser local storage.
- First full-game victory awards 1,000,000,000 coins.
- Second full-game victory unlocks all currently implemented cars and skins.
- Progress is saved on the current browser/device; clearing browser data or changing devices can remove/reset this local save.
